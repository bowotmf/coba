
import React, { useState, useCallback, ChangeEvent, useEffect } from 'react';
import {
  timeOfDayOptions,
  cameraMovementOptions,
  lightingStyleOptions,
  videoStyleOptions,
  videoMoodOptions,
  creativeAssistantCategoryOptions,
} from './constants';
import { SelectOption } from './types';
import { generateCreativePromptFromElements, fetchCreativeAssistantIdeasFromGemini } from './services/geminiService';

const DEFAULT_NEGATIVE_PROMPT_ID = "Hindari: teks di layar, subtitle, tulisan di video, font, logo, distorsi, artefak, anomali, wajah ganda, anggota badan cacat, tangan tidak normal, orang tambahan, objek mengganggu, kualitas rendah, buram, glitch, suara robotik, suara pecah.";
const DEFAULT_NEGATIVE_PROMPT_EN = "Avoid: on-screen text, subtitles, text in video, fonts, logos, distortion, artifacts, anomalies, double faces, deformed limbs, abnormal hands, extra people, distracting objects, low quality, blur, glitch, robotic voice, broken voice.";

const DEFAULT_NEGATIVE_PROMPTS = {
  id: DEFAULT_NEGATIVE_PROMPT_ID,
  en: DEFAULT_NEGATIVE_PROMPT_EN,
};

type OutputLanguage = 'id' | 'en';

// Helper to get localized value from "English (Indonesian)" format
function getLocalizedValue(optionValue: string, lang: OutputLanguage): string {
  if (!optionValue) return '';
  const parts = optionValue.match(/^(.*?)(\s*\((.*?)\))?$/);
  if (!parts) return optionValue; // Fallback

  const englishPart = parts[1].trim();
  const indonesianPart = parts[3]?.trim();

  if (lang === 'id') {
    return indonesianPart || englishPart; 
  }
  return englishPart;
}


const App: React.FC = () => {
  const [subject, setSubject] = useState<string>('');
  const [action, setAction] = useState<string>('');
  const [expression, setExpression] = useState<string>('');
  const [setting, setSetting] = useState<string>('');
  const [timeOfDay, setTimeOfDay] = useState<string>('');
  const [cameraMovement, setCameraMovement] = useState<string>('');
  const [lightingStyle, setLightingStyle] = useState<string>('');
  const [videoStyle, setVideoStyle] = useState<string>('');
  const [videoMood, setVideoMood] = useState<string>('');
  const [soundMusic, setSoundMusic] = useState<string>('');
  const [spokenNarration, setSpokenNarration] = useState<string>('');
  const [additionalDetails, setAdditionalDetails] = useState<string>('');
  
  const [outputLanguage, setOutputLanguage] = useState<OutputLanguage>('id');
  const [editableNegativePrompt, setEditableNegativePrompt] = useState<string>(DEFAULT_NEGATIVE_PROMPTS.id);

  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const [creativeAssistantKeyword, setCreativeAssistantKeyword] = useState<string>('');
  const [creativeAssistantCategory, setCreativeAssistantCategory] = useState<string>('General Inspiration');
  const [creativeAssistantIdeas, setCreativeAssistantIdeas] = useState<string>('');
  const [isGettingIdeas, setIsGettingIdeas] = useState<boolean>(false);

  const handleLanguageChange = (event: ChangeEvent<HTMLInputElement>) => {
    const newLang = event.target.value as OutputLanguage;
    const oldLang = outputLanguage;
    setOutputLanguage(newLang);

    if (editableNegativePrompt === DEFAULT_NEGATIVE_PROMPTS[oldLang]) {
      setEditableNegativePrompt(DEFAULT_NEGATIVE_PROMPTS[newLang]);
    }
  };
  
  const constructMainPromptInternal = useCallback((): string => {
    const promptElements: { id_label: string, en_label: string, value: string, isSelect?: boolean }[] = [
      { id_label: 'Subjek', en_label: 'Subject', value: subject },
      { id_label: 'Aksi', en_label: 'Action', value: action },
      { id_label: 'Ekspresi', en_label: 'Expression', value: expression },
      { id_label: 'Tempat/Lingkungan', en_label: 'Setting/Environment', value: setting },
      { id_label: 'Waktu Kejadian', en_label: 'Time of Day', value: timeOfDay, isSelect: true },
      { id_label: 'Gerakan Kamera', en_label: 'Camera Movement', value: cameraMovement, isSelect: true },
      { id_label: 'Gaya Pencahayaan', en_label: 'Lighting Style', value: lightingStyle, isSelect: true },
      { id_label: 'Gaya Video/Estetika', en_label: 'Video Style/Aesthetics', value: videoStyle, isSelect: true },
      { id_label: 'Suasana Video', en_label: 'Video Mood', value: videoMood, isSelect: true },
      { id_label: 'Suara/Musik', en_label: 'Sound/Music', value: soundMusic },
      { id_label: 'Narasi/Dialog', en_label: 'Narration/Dialogue', value: spokenNarration },
      { id_label: 'Detail Tambahan', en_label: 'Additional Details', value: additionalDetails },
    ];

    const promptParts: string[] = [];
    promptElements.forEach(el => {
      if (el.value) {
        const label = outputLanguage === 'id' ? el.id_label : el.en_label;
        const val = el.isSelect ? getLocalizedValue(el.value, outputLanguage) : el.value;
        promptParts.push(`${label}: ${val}`);
      }
    });
    
    let baseInstruction: string;
    let finalInstruction: string;
    const langForInstruction = outputLanguage === 'id' ? "Indonesia" : "Inggris";


    if (promptParts.length === 0) {
      baseInstruction = outputLanguage === 'id' 
        ? `Hasilkan satu prompt menulis kreatif yang singkat dan inspiratif secara umum dalam bahasa ${langForInstruction}.`
        : `Generate one short and generally inspiring creative writing prompt in ${langForInstruction}.`;
    } else {
      baseInstruction = outputLanguage === 'id' 
        ? `Hasilkan satu prompt menulis kreatif yang mendetail dan inspiratif dalam bahasa ${langForInstruction}, menggabungkan elemen-elemen berikut:\n\n${promptParts.join('\n')}`
        : `Generate one detailed and inspiring creative writing prompt in ${langForInstruction}, incorporating the following elements:\n\n${promptParts.join('\n')}`;
    }

    finalInstruction = outputLanguage === 'id' 
      ? "Pastikan prompt akhir bersifat koheren dan menggugah imajinasi."
      : "Ensure the final prompt is coherent and sparks imagination.";

    let llmPrompt = baseInstruction;

    if (editableNegativePrompt.trim()) {
      llmPrompt += `\n\n${editableNegativePrompt.trim()}`;
    }
    llmPrompt += `\n\n${finalInstruction}`;
    return llmPrompt;

  }, [subject, action, expression, setting, timeOfDay, cameraMovement, lightingStyle, videoStyle, videoMood, soundMusic, spokenNarration, additionalDetails, editableNegativePrompt, outputLanguage]);

  const handleGeneratePrompt = useCallback(async () => {
    setIsGenerating(true);
    setGeneratedPrompt('');
    setCopied(false);
    const llmPrompt = constructMainPromptInternal();

    try {
      const resultText = await generateCreativePromptFromElements(llmPrompt);
      setGeneratedPrompt(resultText);
    } catch (error) {
      console.error("Error generating prompt in App component:", error);
      const errorMsg = outputLanguage === 'id' 
        ? "Terjadi kesalahan saat menghasilkan prompt. Silakan coba lagi. Pastikan API Key sudah terkonfigurasi dengan benar."
        : "An error occurred while generating the prompt. Please try again. Ensure the API Key is correctly configured.";
      setGeneratedPrompt(errorMsg);
    } finally {
      setIsGenerating(false);
    }
  }, [constructMainPromptInternal, outputLanguage]);

  const clearAllInputs = useCallback(() => {
    setSubject('');
    setAction('');
    setExpression('');
    setSetting('');
    setTimeOfDay('');
    setCameraMovement('');
    setLightingStyle('');
    setVideoStyle('');
    setVideoMood('');
    setSoundMusic('');
    setSpokenNarration('');
    setAdditionalDetails('');
    
    setOutputLanguage('id'); // Reset language to Indonesian
    setEditableNegativePrompt(DEFAULT_NEGATIVE_PROMPTS.id); // Reset negative prompt to Indonesian default

    setGeneratedPrompt('');
    setCopied(false);
    setCreativeAssistantKeyword('');
    setCreativeAssistantCategory('General Inspiration');
    setCreativeAssistantIdeas('');
  }, []);

  const constructCreativeAssistantPromptInternal = useCallback((): string => {
    let llmPrompt = `Berikan beberapa ide untuk kategori "${creativeAssistantCategory}" dalam bahasa Indonesia. `;
    if (creativeAssistantKeyword.trim() !== '') {
      llmPrompt += `Ide-ide tersebut harus berhubungan dengan kata kunci atau ide ini: "${creativeAssistantKeyword.trim()}".`;
    } else {
      llmPrompt += `Berikan ide-ide umum dan menarik.`;
    }
    llmPrompt += ` Harap berikan ide-ide dalam format daftar poin atau paragraf singkat.`;
    return llmPrompt;
  }, [creativeAssistantCategory, creativeAssistantKeyword]);
  
  const handleGetCreativeAIDeas = useCallback(async () => {
    setIsGettingIdeas(true);
    setCreativeAssistantIdeas('');
    const llmPrompt = constructCreativeAssistantPromptInternal();

    try {
      const resultText = await fetchCreativeAssistantIdeasFromGemini(llmPrompt);
      setCreativeAssistantIdeas(resultText);
    } catch (error) {
      console.error("Error getting creative assistant ideas in App component:", error);
      setCreativeAssistantIdeas("Terjadi kesalahan saat mendapatkan ide. Silakan coba lagi. Pastikan API Key sudah terkonfigurasi dengan benar.");
    } finally {
      setIsGettingIdeas(false);
    }
  }, [constructCreativeAssistantPromptInternal]);

  const handleCopyPrompt = useCallback(() => {
    if (generatedPrompt) {
      navigator.clipboard.writeText(generatedPrompt)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        })
        .catch(err => {
          console.error('Failed to copy prompt: ', err);
          // Optionally, inform the user about the copy failure
        });
    }
  }, [generatedPrompt]);


  const inputClass = "w-full px-4 py-2.5 border border-purple-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-sm transition-colors duration-200 ease-in-out hover:border-purple-400";
  const selectClass = `${inputClass} bg-white`;
  const labelClass = "block text-gray-700 text-sm font-semibold mb-2";

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-indigo-100 to-blue-100 flex items-center justify-center p-4 sm:p-6 lg:p-8 font-sans">
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-3xl">
        <header className="mb-8 text-center">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 mb-3">
            Generator Prompt Kreatif
          </h1>
          <p className="text-gray-600 text-sm sm:text-base">
            Bangun prompt tulisan yang unik dengan memilih berbagai elemen atau dapatkan ide dari Asisten Kreatif kami.
          </p>
        </header>

        <section className="mb-10">
          <h2 className="text-2xl font-bold text-purple-700 mb-6 border-b-2 border-purple-200 pb-2">
            Elemen Konstruksi Prompt
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            {[
              {id: "subject", label: "1. Subjek", value: subject, setter: setSubject, placeholder: "misalnya: Seorang penjelajah waktu"},
              {id: "action", label: "2. Aksi", value: action, setter: setAction, placeholder: "misalnya: menemukan artefak kuno"},
              {id: "expression", label: "3. Ekspresi", value: expression, setter: setExpression, placeholder: "misalnya: dengan ekspresi terkejut"},
              {id: "setting", label: "4. Tempat/Lingkungan", value: setting, setter: setSetting, placeholder: "misalnya: di kota masa depan yang sepi"}
            ].map(item => (
              <div key={item.id} className="mb-1">
                <label htmlFor={item.id} className={labelClass}>{item.label}</label>
                <input type="text" id={item.id} value={item.value} onChange={(e: ChangeEvent<HTMLInputElement>) => item.setter(e.target.value)} className={inputClass} placeholder={item.placeholder} aria-label={item.label}/>
              </div>
            ))}
            
            {[
              {id: "timeOfDay", label: "5. Waktu Kejadian", value: timeOfDay, setter: setTimeOfDay, options: timeOfDayOptions},
              {id: "cameraMovement", label: "6. Gerakan Kamera", value: cameraMovement, setter: setCameraMovement, options: cameraMovementOptions},
              {id: "lightingStyle", label: "7. Gaya Pencahayaan", value: lightingStyle, setter: setLightingStyle, options: lightingStyleOptions},
              {id: "videoStyle", label: "8. Gaya Video/Estetika", value: videoStyle, setter: setVideoStyle, options: videoStyleOptions}
            ].map(item => (
              <div key={item.id} className="mb-1">
                <label htmlFor={item.id} className={labelClass}>{item.label}</label>
                <select id={item.id} value={item.value} onChange={(e: ChangeEvent<HTMLSelectElement>) => item.setter(e.target.value)} className={selectClass} aria-label={item.label}>
                  {item.options.map((option: SelectOption) => <option key={option.value} value={option.value}>{option.label}</option>)}
                </select>
              </div>
            ))}

            <div className="mb-1 md:col-span-2">
              <label htmlFor="videoMood" className={labelClass}>9. Suasana Video</label>
              <select id="videoMood" value={videoMood} onChange={(e: ChangeEvent<HTMLSelectElement>) => setVideoMood(e.target.value)} className={selectClass} aria-label="Suasana Video">
                {videoMoodOptions.map((option: SelectOption) => <option key={option.value} value={option.value}>{option.label}</option>)}
              </select>
            </div>

            <div className="mb-1 md:col-span-2">
              <label htmlFor="soundMusic" className={labelClass}>10. Suara/Musik</label>
              <input type="text" id="soundMusic" value={soundMusic} onChange={(e: ChangeEvent<HTMLInputElement>) => setSoundMusic(e.target.value)} className={inputClass} placeholder="misalnya: musik orkestra yang epik" aria-label="Suara atau Musik"/>
            </div>

            <div className="mb-1 md:col-span-2">
              <label htmlFor="spokenNarration" className={labelClass}>11. Narasi/Dialog</label>
              <input type="text" id="spokenNarration" value={spokenNarration} onChange={(e: ChangeEvent<HTMLInputElement>) => setSpokenNarration(e.target.value)} className={inputClass} placeholder="misalnya: narasi tentang takdir" aria-label="Narasi atau Dialog"/>
            </div>

            <div className="mb-1 md:col-span-2">
              <label htmlFor="additionalDetails" className={labelClass}>12. Detail Tambahan</label>
              <textarea id="additionalDetails" value={additionalDetails} onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setAdditionalDetails(e.target.value)} rows={3} className={inputClass} placeholder="misalnya: dengan efek visual realistis dan detail rumit" aria-label="Detail Tambahan"></textarea>
            </div>
            
            <div className="mb-1 md:col-span-2">
              <label htmlFor="negativePrompt" className={labelClass}>13. Negative Prompt</label>
              <textarea
                id="negativePrompt"
                value={editableNegativePrompt}
                onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setEditableNegativePrompt(e.target.value)}
                rows={4}
                className={inputClass}
                aria-describedby="negativePromptHelp"
                aria-label="Negative Prompt"
              />
              <p id="negativePromptHelp" className="text-xs text-gray-500 mt-1 px-1">
                Secara default berisi batasan umum. Anda dapat mengubah atau menambahkan batasan spesifik Anda. Jika bahasa output diubah, prompt negatif default juga akan disesuaikan jika belum diubah.
              </p>
            </div>
          </div>
          
          <div className="mt-8 mb-4 md:col-span-2">
            <label className={labelClass}>Bahasa Output Prompt</label>
            <div className="flex gap-4 items-center">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="outputLanguage"
                  value="id"
                  checked={outputLanguage === 'id'}
                  onChange={handleLanguageChange}
                  className="form-radio h-4 w-4 text-purple-600 border-gray-300 focus:ring-purple-500"
                />
                <span className="text-gray-700">Bahasa Indonesia</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="radio"
                  name="outputLanguage"
                  value="en"
                  checked={outputLanguage === 'en'}
                  onChange={handleLanguageChange}
                  className="form-radio h-4 w-4 text-purple-600 border-gray-300 focus:ring-purple-500"
                />
                <span className="text-gray-700">Bahasa Inggris</span>
              </label>
            </div>
          </div>


          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <button onClick={handleGeneratePrompt} disabled={isGenerating} className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-indigo-300 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center">
              {isGenerating ? (<><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Menghasilkan...</>) : "Hasilkan Prompt AI"}
            </button>
            <button onClick={clearAllInputs} className="flex-1 bg-gray-200 text-gray-700 font-bold py-3 px-6 rounded-lg shadow-md hover:bg-gray-300 hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-gray-300">
              Hapus Semua Input
            </button>
          </div>
        </section>

        {generatedPrompt && (
          <section className="mt-10 bg-purple-50 border border-purple-200 rounded-lg p-6 shadow-md">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-xl font-bold text-purple-700">Prompt yang Dihasilkan:</h3>
              <button
                onClick={handleCopyPrompt}
                className="bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-lg text-sm transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-400 disabled:opacity-50"
                disabled={copied}
                aria-label={copied ? "Prompt Tersalin" : "Salin Prompt"}
              >
                {copied ? "Tersalin!" : "Salin Prompt"}
              </button>
            </div>
            <pre className="text-gray-800 leading-relaxed whitespace-pre-wrap font-sans">{generatedPrompt}</pre>
          </section>
        )}

        <hr className="my-10 border-t-2 border-purple-200" />

        <section className="mb-8">
          <h2 className="text-2xl font-bold text-indigo-700 mb-6 border-b-2 border-indigo-200 pb-2">
            Asisten Kreatif (AI)
          </h2>
          <p className="text-gray-600 mb-6">Dapatkan ide-ide AI untuk elemen prompt tertentu (output tetap Bahasa Indonesia).</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            <div className="mb-1">
              <label htmlFor="creativeAssistantKeyword" className={labelClass}>Kata Kunci / Ide (opsional)</label>
              <input type="text" id="creativeAssistantKeyword" value={creativeAssistantKeyword} onChange={(e: ChangeEvent<HTMLInputElement>) => setCreativeAssistantKeyword(e.target.value)} className="w-full px-4 py-2.5 border border-indigo-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm transition-colors duration-200 ease-in-out hover:border-indigo-400" placeholder="misalnya: hutan, robot, cinta" aria-label="Kata Kunci untuk Asisten Kreatif"/>
            </div>
            <div className="mb-1">
              <label htmlFor="creativeAssistantCategory" className={labelClass}>Kategori untuk Saran</label>
              <select id="creativeAssistantCategory" value={creativeAssistantCategory} onChange={(e: ChangeEvent<HTMLSelectElement>) => setCreativeAssistantCategory(e.target.value)} className="w-full px-4 py-2.5 border border-indigo-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white shadow-sm transition-colors duration-200 ease-in-out hover:border-indigo-400" aria-label="Kategori untuk Saran Asisten Kreatif">
                {creativeAssistantCategoryOptions.map((option: SelectOption) => <option key={option.value} value={option.value}>{option.label}</option>)}
              </select>
            </div>
          </div>
          <button onClick={handleGetCreativeAIDeas} disabled={isGettingIdeas} className="w-full mt-6 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-blue-300 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center">
            {isGettingIdeas ? (<><svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>Mendapatkan Ide...</>) : "Dapatkan Ide AI"}
          </button>
          {creativeAssistantIdeas && (
            <div className="mt-8 bg-indigo-50 border border-indigo-200 rounded-lg p-6 shadow-md">
              <h3 className="text-xl font-bold text-indigo-700 mb-3">Ide Asisten Kreatif Anda:</h3>
              <pre className="text-gray-800 leading-relaxed whitespace-pre-wrap font-sans">{creativeAssistantIdeas}</pre>
            </div>
          )}
        </section>
        <footer className="text-center mt-12 text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} Creative Prompt Generator. Powered by Gemini AI.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
