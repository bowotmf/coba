
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// IMPORTANT: The API key MUST be obtained EXCLUSIVELY from the environment variable `process.env.API_KEY`.
// This variable is assumed to be pre-configured and accessible in the execution environment.
// The application MUST NOT prompt the user for the API key or provide UI for its input.
const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
let apiKeyMissingErrorLogged = false;

if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  if (!apiKeyMissingErrorLogged) {
    console.error(
      "Gemini API Key is missing. Please set the API_KEY environment variable. " +
      "The application will not be able to connect to the Gemini API."
    );
    apiKeyMissingErrorLogged = true; 
  }
}

const MODEL_NAME = 'gemini-2.5-flash-preview-04-17';

const handleGeminiError = (error: unknown, context: string): string => {
  console.error(`Error calling Gemini API for ${context}:`, error);
  if (error instanceof Error) {
    // Check for specific error messages that might indicate an API key issue
    if (error.message.includes("API key not valid") || error.message.includes("PERMISSION_DENIED")) {
        return `Error with Gemini API: API key is invalid or missing permissions. Please check your API key configuration. Context: ${context}.`;
    }
    return `Error with Gemini API: ${error.message}. Context: ${context}.`;
  }
  return `An unknown error occurred while interacting with the Gemini API. Context: ${context}.`;
};

export const generateCreativePromptFromElements = async (promptText: string): Promise<string> => {
  if (!ai) {
    return "Error: Gemini API client is not initialized. This is likely due to a missing API Key.";
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: promptText,
    });
    return response.text;
  } catch (error) {
    return handleGeminiError(error, "prompt generation");
  }
};

export const fetchCreativeAssistantIdeasFromGemini = async (promptText: string): Promise<string> => {
  if (!ai) {
     return "Error: Gemini API client is not initialized. This is likely due to a missing API Key.";
  }
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: promptText,
    });
    return response.text;
  } catch (error) {
    return handleGeminiError(error, "creative assistant ideas");
  }
};
